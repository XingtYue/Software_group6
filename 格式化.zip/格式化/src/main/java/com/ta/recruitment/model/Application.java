package com.ta.recruitment.model;

public class Application {
    private String id;
    private String jobId;
    private String jobTitle;
    private String taId;
    private String taName;
    private String taEmail;
    private String status; // "pending", "accepted", "rejected"
    private String appliedDate;
    private String coverLetter;
    private String cvFileName;

    public Application() {
        this.status = "pending";
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getJobId() { return jobId; }
    public void setJobId(String jobId) { this.jobId = jobId; }

    public String getJobTitle() { return jobTitle; }
    public void setJobTitle(String jobTitle) { this.jobTitle = jobTitle; }

    public String getTaId() { return taId; }
    public void setTaId(String taId) { this.taId = taId; }

    public String getTaName() { return taName; }
    public void setTaName(String taName) { this.taName = taName; }

    public String getTaEmail() { return taEmail; }
    public void setTaEmail(String taEmail) { this.taEmail = taEmail; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getAppliedDate() { return appliedDate; }
    public void setAppliedDate(String appliedDate) { this.appliedDate = appliedDate; }

    public String getCoverLetter() { return coverLetter; }
    public void setCoverLetter(String coverLetter) { this.coverLetter = coverLetter; }

    public String getCvFileName() { return cvFileName; }
    public void setCvFileName(String cvFileName) { this.cvFileName = cvFileName; }

    public java.util.Map<String,String> toMap() {
        java.util.Map<String,String> m = new java.util.LinkedHashMap<>();
        m.put("id", id);
        m.put("jobId", jobId);
        m.put("jobTitle", jobTitle != null ? jobTitle : "");
        m.put("taId", taId);
        m.put("taName", taName != null ? taName : "");
        m.put("taEmail", taEmail != null ? taEmail : "");
        m.put("name", taName != null ? taName : "");
        m.put("email", taEmail != null ? taEmail : "");
        m.put("status", status != null ? status : "pending");
        m.put("appliedDate", appliedDate != null ? appliedDate : "");
        m.put("submittedAt", appliedDate != null ? appliedDate : "");
        return m;
    }
}
